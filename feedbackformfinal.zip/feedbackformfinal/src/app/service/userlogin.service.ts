import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Login} from '../model/userlogin';

@Injectable({
  providedIn: 'root'
})
export class UserloginService {

  baseurl: string= "http://localhost:3000/Login";

  constructor(private http:HttpClient) { }

  userLogin(Login:Login){
    return this.http.post(this.baseurl,Login);
  }
  
}
